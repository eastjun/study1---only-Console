package member.DTO;

public class MemberDTO {
	private String userID;
	private String password;
	private String nickname;
	private String userName;
	private String birthday;
	private String emailAddress;
	private String phoneNum;
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	@Override
	public String toString() {
		return "MemberDTO [userID=" + userID + ", password=" + password + ", nickname=" + nickname + ", userName="
				+ userName + ", birthday=" + birthday + ", emailAddress=" + emailAddress + ", phoneNum=" + phoneNum
				+ "]";
	}
	
	

}
