package member.service;

import java.util.ArrayList;

import member.DTO.MemberDTO;

public interface MemberService {
	
	public ArrayList<MemberDTO> memberSelectAll();
	
	public void memberInsert(MemberDTO memberDTO);
	
	public MemberDTO memberUpdate(MemberDTO memberDTO);
	
	public MemberDTO memberDelete(String id);
	
	public MemberDTO memberSelect(String id);
	
	public MemberDTO memberLogin(String id, String password);

	public MemberDTO nicknamecheck(String nickname);
	
	
}
