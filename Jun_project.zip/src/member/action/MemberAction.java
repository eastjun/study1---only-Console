package member.action;

import java.util.Scanner;

public interface MemberAction {

	public void execute(Scanner scanner);
}
