package member.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jun.member.jdbc.Context;
import member.DTO.MemberDTO;
import member.service.MemberService;

public class MemberDAO implements MemberService {

	private static final Log log = LogFactory.getLog(MemberDAO.class);

	@Override
	public ArrayList<MemberDTO> memberSelectAll() {

		ArrayList<MemberDTO> arrayList = new ArrayList<MemberDTO>();
		MemberDAO memberDAO = new MemberDAO();

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {
			Context context = new Context();
			DataSource dataSource = context.basicDataSource;
			connection = dataSource.getConnection();

			log.info("DB 연결 성공!!" + connection);

			String sql = "Select * from Join_Member";

			log.info("SQL 확인 - " + sql);

			// DB 접속
			preparedStatement = connection.prepareStatement(sql);
			resultSet = preparedStatement.executeQuery();
			// 검색한 데이터 인스턴스에 저장
			while (resultSet.next()) {
				MemberDTO memberDTO = new MemberDTO();
				memberDTO.setUserID(resultSet.getString("userID"));
				memberDTO.setPassword(resultSet.getString("password"));
				memberDTO.setUserName(resultSet.getString("username"));
				memberDTO.setBirthday(resultSet.getString("birthday"));
				memberDTO.setNickname(resultSet.getString("nickname"));
				memberDTO.setEmailAddress(resultSet.getString("emailAddress"));
				memberDTO.setPhoneNum(resultSet.getString("phoneNum"));

				arrayList.add(memberDTO);

			}
			// 현재 행 번호 검색
			resultSet.getRow();
			if (resultSet.getRow() == 0) {
				log.info("등록한 정보가 없습니다.");
			}

		} catch (SQLException e) {
			log.info("예외 확인 -" + e);
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return arrayList;

	}

	@Override
	public void memberInsert(MemberDTO memberDTO) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		// MemberDTO memberDTO1 = new MemberDTO();

		try {
			Context context = new Context();
			DataSource dataSource = context.basicDataSource;
			connection = dataSource.getConnection();

			log.info("DB 연결 성공!!" + connection);

			String sql = "insert into join_member"
					+ "(userid, password, username, birthday, nickname, emailaddress, phonenum)";
			sql += " values (?, ?, ?, to_date(?, 'yyyy-mm-dd'), ?, ?, ?)";

			log.info("SQL 확인 - " + sql);

			// DB 접속
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, memberDTO.getUserID());
			preparedStatement.setString(2, memberDTO.getPassword());
			preparedStatement.setString(3, memberDTO.getUserName());
			preparedStatement.setString(4, memberDTO.getBirthday());
			preparedStatement.setString(5, memberDTO.getNickname());
			preparedStatement.setString(6, memberDTO.getEmailAddress());
			preparedStatement.setString(7, memberDTO.getPhoneNum());

			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			log.info("예외 확인 -" + e);
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return;
	}

	@Override
	public MemberDTO memberUpdate(MemberDTO memberDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MemberDTO memberDelete(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MemberDTO memberSelect(String id) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		MemberDTO memberDTO = new MemberDTO();

		try {
			Context context = new Context();
			DataSource dataSource = context.basicDataSource;
			connection = dataSource.getConnection();

			log.info("DB 연결 성공!!" + connection);

			String sql = "Select * from join_member ";
			sql += " where userid = ?";

			log.info("SQL 확인 - " + sql);

			// DB 접속
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			resultSet = preparedStatement.executeQuery();

			// 호출한 정보 저장
			while (resultSet.next()) {
				memberDTO.setUserID(resultSet.getString("userid"));
				memberDTO.setPassword(resultSet.getString("password"));
				memberDTO.setUserName(resultSet.getString("username"));
				memberDTO.setNickname(resultSet.getString("nickname"));
				memberDTO.setBirthday(resultSet.getString("birthday"));
				memberDTO.setEmailAddress(resultSet.getString("emailaddress"));
				memberDTO.setPhoneNum(resultSet.getString("phonenum"));

			}

		} catch (SQLException e) {
			log.info("예외 확인 -" + e);
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return memberDTO;

	}

	@Override
	public MemberDTO memberLogin(String id, String password) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		MemberDTO memberDTO = new MemberDTO();
//		memberDTO.setUserID(id);
//		memberDTO.setPassword(password);

		try {
			Context context = new Context();
			DataSource dataSource = context.basicDataSource;
			connection = dataSource.getConnection();

			log.info("DB 연결 성공!!" + connection);

			String sql = "select * from join_member ";
			sql += " where userid = ? and password = ?";

			log.info("SQL 확인 - " + sql);

			// DB 접속
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			preparedStatement.setString(2, password);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {

				if (resultSet.getString("userid").equals(id) & resultSet.getString("password").equals(password)) {
					memberDTO.setUserID(resultSet.getString("userid"));
					log.info("id 확인 - " + resultSet.getString("userid"));
					memberDTO.setPassword(resultSet.getString("password"));
					log.info("pw 확인 - " + resultSet.getString("password"));
				}
			}

		} catch (SQLException e) {
			log.info("로그인 실패 확인 -" + e);
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return memberDTO;
	}

	@Override
	public MemberDTO nicknamecheck(String nickname) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		MemberDTO memberDTO = new MemberDTO();

		try {
			Context context = new Context();
			DataSource dataSource = context.basicDataSource;
			connection = dataSource.getConnection();

			log.info("DB 연결 성공!!" + connection);

			String sql = "Select * from join_member ";
			sql += " where nickname = ?";

			log.info("SQL 확인 - " + sql);

			// DB 접속
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, nickname);
			resultSet = preparedStatement.executeQuery();

			// 호출한 정보 저장
			while (resultSet.next()) {
				memberDTO.setUserID(resultSet.getString("userid"));
				memberDTO.setPassword(resultSet.getString("password"));
				memberDTO.setUserName(resultSet.getString("username"));
				memberDTO.setNickname(resultSet.getString("nickname"));
				memberDTO.setBirthday(resultSet.getString("birthday"));
				memberDTO.setEmailAddress(resultSet.getString("emailaddress"));
				memberDTO.setPhoneNum(resultSet.getString("phonenum"));

			}

		} catch (SQLException e) {
			log.info("예외 확인 -" + e);
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return memberDTO;

	}

	public MemberDTO memberIDCheck(String id) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		MemberDTO memberDTO = new MemberDTO();

		try {
			Context context = new Context();
			DataSource dataSource = context.basicDataSource;
			connection = dataSource.getConnection();

			log.info("DB 연결 성공!!" + connection);

			String sql = "Select * from join_member";
			sql += " where userid =? ";

			log.info("SQL 확인 - " + sql);

			// DB 접속
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				if (resultSet.getString("userid").equals(id)) {
					memberDTO.setUserID(resultSet.getString("userid"));

				}

			}

		} catch (SQLException e) {
			log.info("예외 확인 -" + e);
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return memberDTO;

	}

	public MemberDTO memberPWCheck(String password) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		MemberDTO memberDTO = new MemberDTO();

		try {
			Context context = new Context();
			DataSource dataSource = context.basicDataSource;
			connection = dataSource.getConnection();

			log.info("DB 연결 성공!!" + connection);

			String sql = "Select * from join_member";
			sql += " where password =? ";

			log.info("SQL 확인 - " + sql);

			// DB 접속
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, password);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				if (resultSet.getString("password").equals(password)) {
					memberDTO.setUserID(resultSet.getString("password"));

				}

			}

		} catch (SQLException e) {
			log.info("예외 확인 -" + e);
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return memberDTO;

	}
}