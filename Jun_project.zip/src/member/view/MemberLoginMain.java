package member.view;

import java.util.Scanner;

import board.view.BoardMain;
import member.DAO.MemberDAO;
import member.DTO.MemberDTO;
import member.control.MemberFind;
import member.control.MemberInsert;

public class MemberLoginMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		MemberDTO memberDTO = new MemberDTO();
		MemberInsert memberInsert = new MemberInsert();
		MemberFind memberFind = new MemberFind();
		MemberDAO memberDAO = new MemberDAO();
		
		do {
			System.out.println("=====로그인=====");
			System.out.println("번호를 선택해 주세요.");
			System.out.println("1. 로그인 2. 회원가입 3. 아이디/비밀번호 찾기 4. 게시판");
			System.out.print("번호: ");
			String choiceMenu = scanner.next();
			switch (choiceMenu) {

			case "1":
				System.out.println("===로그인===");
				System.out.print("아이디: ");
				String userID = scanner.next();

				System.out.print("비밀번호: ");
				String password = scanner.next();
				
				memberDTO =memberDAO.memberLogin(userID, password);
				
				if (userID.equals(memberDTO.getUserID()) && password.equals(memberDTO.getPassword())) {
					
					System.out.println("<<<<<"+memberDTO.getUserID()+" 님 환영합니다.>>>>>");	
					System.out.println();
					BoardMain.main(null);
				}
				else {
					System.out.println("<아이디 비밀번호가 일치하지 않습니다.>");		
					System.out.println();
				}
				break;

			case "2":
				System.out.println("===회원가입화면으로 이동합니다.>>>");
				System.out.println();
				memberInsert.execute(scanner);
				break;

			case "3":
				System.out.println("===아이디/비밀번호 찾기로 이동합니다.>>>>");
				System.out.println();
				memberFind.execute(scanner);

				break;
				
			case "4":
				BoardMain.main(null);
				System.out.println();
				break;
				
				default:
				System.out.println("잘못 입력하셨습니다.");
				MemberLoginMain.main(null);
			}

		} while (true);

	}
}
