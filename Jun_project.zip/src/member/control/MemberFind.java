package member.control;

import java.util.ArrayList;
import java.util.Scanner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import member.DAO.MemberDAO;
import member.DTO.MemberDTO;
import member.action.MemberAction;
import member.view.MemberLoginMain;

public class MemberFind implements MemberAction {

	private static final Log log = LogFactory.getLog(MemberFind.class);

	@Override
	public void execute(Scanner scanner) {
		System.out.println("====아이디 비밀번호 찾기====");
		System.out.println("번호를 선택하세요");
		System.out.println("1. 아이디 찾기 2. 비밀번호 찾기 3. 로그인");
		System.out.print("번호 : ");

		ArrayList<MemberDTO> arrayList = new ArrayList<MemberDTO>();
		MemberDAO memberDAO = new MemberDAO();
		arrayList = memberDAO.memberSelectAll();

		String choice = scanner.next();
		switch (choice) {
		case "1":

			System.out.println("===아이디 찾기===");
			log.info("아이디 확인" + arrayList);
			System.out.println("이름을 입력하세요");
			System.out.print("이름: ");
			String userName = scanner.next();

			System.out.println("휴대폰 번호를 입력하세요");
			System.out.print("번호: ");
			String phoneNum = scanner.next();
			boolean found = false;

			for (MemberDTO memberDTO : arrayList) {

				String name = memberDTO.getUserName();
				String phoneN = memberDTO.getPhoneNum();
				String userID = memberDTO.getUserID();

				if (userName.equals(name) && phoneNum.equals(phoneN)) {

					System.out.println(name + "님의 아이디는 " + userID + " 입니다.");
					found = true;
					break;
				}
			}

			if (!found) {
				System.out.println("회원 정보가 틀렸습니다.");
			}
			break;

		case "2":

			System.out.println("===비밀번호 찾기===");
			System.out.println("아이디를 입력하세요");
			System.out.print("아이디: ");
			String id = scanner.next();
			System.out.println("이름을 입력하세요");
			System.out.print("이름 :");
			String name = scanner.next();

			boolean found2 = false;
			for (MemberDTO memberDTO : arrayList) {
				String userID = memberDTO.getUserID();
				String username = memberDTO.getUserName();
				String password = memberDTO.getPassword();

				if (id.equals(userID) && name.equals(username)) {

					System.out.println(userID + "님의 비밀번호는 " + password + " 입니다.");

					found2 = true;
					break;
				}
			}
			if (!found2) {
				System.out.println("회원 정보가 틀렸습니다.");
			}
			break;
		case "3":
			System.out.println("로그인 화면으로 이동합니다>>>>");
			MemberLoginMain.main(null);

			break;

		default:

			System.out.println("<잘못 입력했습니다.>");
			System.out.println();
			MemberFind memberFind = new MemberFind();
			memberFind.execute(scanner);

			break;
		}
	}

}
