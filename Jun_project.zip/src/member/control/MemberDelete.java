package member.control;

public class MemberDelete {

}
