package member.control;

import java.util.ArrayList;
import java.util.Scanner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import member.DAO.MemberDAO;
import member.DTO.MemberDTO;
import member.action.MemberAction;

public class MemberInsert implements MemberAction {

	private static final Log log = LogFactory.getLog(MemberInsert.class);

	@Override
	public void execute(Scanner scanner) {
		System.out.println("<회원 가입 페이지>");

		ArrayList<MemberDTO> arrayList = new ArrayList<MemberDTO>();
		MemberDAO memberDAO = new MemberDAO();
		arrayList = memberDAO.memberSelectAll();

		MemberDTO memberDTO = new MemberDTO();

		String userID = null;
		while (true) {
			System.out.print("아이디 : ");
			userID = scanner.next(); // 중복확인 추가해야함
			memberDTO= memberDAO.memberSelect(userID);

			if (userID.equals(memberDTO.getUserID())) {
				System.out.println("중복된 아이디가 있습니다. 다시 입력하세요");
				
				log.info("중복 아이디 -" + memberDTO.getUserID().equals(userID));
				System.out.println();
				continue;
				
			} else {
				System.out.println("사용 가능한 아이디 입니다.");
			}
			break;
		}

		String password = null;
		System.out.print("비밀번호 : ");
		password = scanner.next();

		while (true) {
			System.out.print("비밀번호 확인 : ");
			String confirmPassword = scanner.next(); // 확인 추가해야함

			if (!password.equals(confirmPassword)) {
				System.out.println("틀렸습니다");
				continue;
			}
			break;
		}
		System.out.print("이름: ");
		String username = scanner.next();

		String nickname = null;
		while (true) {
			System.out.print("닉네임 : "); // 중복확인 추가해야함
			nickname = scanner.next();
			
			if (nickname.equals(memberDTO.getNickname())) {
				System.out.println("이미 사용중인 닉네임 입니다.");
				log.info("닉네임 중복 - " + memberDTO.getNickname().equals(nickname));
				System.out.println();
				continue;
				
			} else {
				System.out.println("사용 가능한 닉네임 입니다.");
			}
			break;
		}

		System.out.print("생년월일 : ");
		String birthday = scanner.next();
		System.out.print("이메일 : ");
		String email = scanner.next();
		System.out.println("전화번호는 숫자만 입력하세요");
		System.out.println("ex)01011112222");
		System.out.print("전화번호 : ");
		String phoneNum = scanner.next();

		memberDTO.setUserID(userID);
		memberDTO.setPassword(password);
		memberDTO.setUserName(username);
		memberDTO.setNickname(nickname);
		memberDTO.setBirthday(birthday);
		memberDTO.setEmailAddress(email);
		memberDTO.setPhoneNum(phoneNum);

		memberDAO.memberInsert(memberDTO);

		System.out.println(nickname + " 님 환영합니다.");

	}

}
