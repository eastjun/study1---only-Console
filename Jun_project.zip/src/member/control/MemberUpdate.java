package member.control;

public class MemberUpdate {

}
