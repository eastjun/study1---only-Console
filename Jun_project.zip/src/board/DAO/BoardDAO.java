package board.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import board.DTO.BoardDTO;
import board.service.Boardservice;
import jun.member.jdbc.Context;


public class BoardDAO implements Boardservice {

	private static final Log log = LogFactory.getLog(BoardDAO.class);

	@Override
	public ArrayList<BoardDTO> boardSelectAll() {

		ArrayList<BoardDTO> arrayList = new ArrayList<BoardDTO>();

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {
			Context context = new Context();
			DataSource dataSource = context.basicDataSource;
			connection = dataSource.getConnection();

			log.info("DB 연결 성공!!" + connection);

			String sql = "Select * from freeboard ";

			log.info("SQL 확인 - " + sql);

			// DB 접속
			preparedStatement = connection.prepareStatement(sql);
			resultSet = preparedStatement.executeQuery();
			
			// 검색한 데이터 인스턴스에 저장
			while (resultSet.next()) {
				BoardDTO boardDTO = new BoardDTO();
				boardDTO.setNum(resultSet.getInt("num"));
				boardDTO.setTitle(resultSet.getString("title"));
				boardDTO.setContent(resultSet.getString("content"));			
				boardDTO.setUserID(resultSet.getString("userid"));
				boardDTO.setWpassword(resultSet.getString("wpassword"));
				boardDTO.setWriteday(resultSet.getString("writeday"));
				
				arrayList.add(boardDTO);

			}
			// 현재 행 번호 검색
			resultSet.getRow();
			if (resultSet.getRow() == 0) {
				log.info("등록한 부서가 없습니다.");
			}

		} catch (SQLException e) {
			log.info("예외 확인 -" + e);
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return arrayList;
	}

	@Override
	public void boardInsert(BoardDTO boardDTO) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			Context context = new Context();
			DataSource dataSource = context.basicDataSource;
			connection = dataSource.getConnection();

			log.info("DB 연결 성공!!" + connection);

			String sql = "insert into freeboard (num,title,content,userid,wpassword,writeday)";
			sql += "values(board_seq.nextval,?,?,?,?,sysdate)";

			log.info("SQL 확인 - " + sql);

			// DB 접속
			preparedStatement = connection.prepareStatement(sql);
			//preparedStatement.setInt(1, boardDTO.getNum());
			preparedStatement.setString(1, boardDTO.getTitle());
			preparedStatement.setString(2, boardDTO.getContent());
			preparedStatement.setString(3, boardDTO.getUserID());
			preparedStatement.setString(4, boardDTO.getWpassword());
			//preparedStatement.setString(6, boardDTO.getWriteday());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			log.info("예외 확인 -" + e);
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public BoardDTO boardUpdate(BoardDTO boardDTO) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			Context context = new Context();
			DataSource dataSource = context.basicDataSource;
			connection = dataSource.getConnection();

			log.info("DB 연결 성공!!" + connection);

			String sql = "update freeboard ";
			sql += "set wpassword=?, title=?, content=? where num =?";

			log.info("SQL 확인 - " + sql);

			// DB 접속
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, boardDTO.getWpassword());
			preparedStatement.setString(2, boardDTO.getTitle());
			preparedStatement.setString(3, boardDTO.getContent());
			preparedStatement.setInt(4, boardDTO.getNum());
			
			int count = preparedStatement.executeUpdate();
			log.info("수정 데이터 확인 -" + boardDTO);
			if (count>0) {
				connection.commit();
				log.info("커밋 완료");
				
			}
			else {
				log.info("롤백 되었습니다");
				
			}

		} catch (SQLException e) {
			log.info("글 수정 실패 확인 -" + e);
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return boardDTO;
	}

	@Override
	public BoardDTO boardDelete(int num, String password) {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		BoardDTO boardDTO = new BoardDTO();
		
		try {
			Context context = new Context();
			DataSource dataSource = context.basicDataSource;
			connection = dataSource.getConnection();

			
			boardDTO.setNum(num);

			log.info("DB 연결 성공!!" + connection);

			String sql = "delete freeboard ";
			sql += "where num =? and wpassword = ?";

			log.info("SQL 확인 - " + sql);

			// DB 접속
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, num);
			preparedStatement.setString(2, password);
			int count =preparedStatement.executeUpdate();
			if (count>0) {
				connection.commit();
				log.info("커밋 되었습니다.");
				
			}
			else {
				connection.rollback();
				log.info("롤백 되었습니다.");
			}

		} catch (SQLException e) {
			log.info("삭제 실패 -" + e);
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return boardDTO;
	}

	@Override
	public BoardDTO boardSelect(int num) {
		
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		BoardDTO boardDTO = new BoardDTO();

		try {
			Context context = new Context();
			DataSource dataSource = context.basicDataSource;
			connection = dataSource.getConnection();

			log.info("DB 연결 성공!!" + connection);

			String sql = "Select * from freeboard ";
			sql += " where num =? ";

			log.info("SQL 확인 - " + sql);

			// DB 접속
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, num);
			resultSet = preparedStatement.executeQuery();

			//호출한 정보 저장
			while (resultSet.next()) {
				boardDTO.setNum(resultSet.getInt("num"));
				boardDTO.setTitle(resultSet.getString("title"));
				boardDTO.setContent(resultSet.getString("content"));
				boardDTO.setUserID(resultSet.getString("userid"));
				boardDTO.setWpassword(resultSet.getString("wpassword"));
				boardDTO.setWriteday(resultSet.getString("writeday"));
			}

		} catch (SQLException e) {
			log.info("예외 확인 -" + e);
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return boardDTO;

	}

	@Override
	public ArrayList<BoardDTO> boardIDCheck(String id) {
		
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ArrayList<BoardDTO>arrayList = new ArrayList<BoardDTO>();
		
		try {
			Context context = new Context();
			DataSource dataSource = context.basicDataSource;
			connection = dataSource.getConnection();

			log.info("DB 연결 성공!!" + connection);

			String sql = "Select b.num, b.title, b.content, b.userid, b.wpassword,to_char(b.writeday, 'yyyy-mm-dd') writeday ";
			sql += " from freeboard b, join_member m ";
			sql += " where b.userid=m.userid and b.userid=? ";

			log.info("SQL 확인 - " + sql);

			// DB 접속
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			resultSet = preparedStatement.executeQuery();

			//호출한 정보 저장
			while (resultSet.next()) {
				BoardDTO boardDTO = new BoardDTO();
				boardDTO.setNum(resultSet.getInt("num"));
				boardDTO.setTitle(resultSet.getString("title"));
				boardDTO.setContent(resultSet.getString("content"));
				boardDTO.setUserID(resultSet.getString("userid"));
				boardDTO.setWriteday(resultSet.getString("writeday"));
				
				arrayList.add(boardDTO);
					
			}
			if (resultSet.getRow()==0) {
				log.info("아이디 확인 불가");
				System.out.println("아이디가 없습니다.");
			}
		} catch (SQLException e) {
			log.info("예외 확인 -" + e);
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return arrayList;

		
	}

}
