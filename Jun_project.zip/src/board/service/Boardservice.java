package board.service;

import java.util.ArrayList;

import board.DTO.BoardDTO;

public interface Boardservice {
public ArrayList<BoardDTO> boardSelectAll();
	
	public void boardInsert(BoardDTO boardDTO);
	
	public BoardDTO boardUpdate(BoardDTO boardDTO);
	
	public BoardDTO boardDelete(int num, String password);
	
	public BoardDTO boardSelect(int num);
	
	public ArrayList<BoardDTO> boardIDCheck(String id);

}
