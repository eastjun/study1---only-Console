package board.view;

import java.util.Scanner;

import board.control.BoardDelete;
import board.control.BoardInsert;
import board.control.BoardSelect;
import board.control.BoardUpdate;
import member.view.MemberLoginMain;

public class BoardMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		do {
			System.out.println("<<<<자유 게시판>>>>");
			System.out.println("==메뉴를 선택하세요==");
			System.out.println("1. 글 목록 2. 글 작성 3. 글 수정 4. 글 삭제 5. 로그인");
			System.out.print("번호: ");

			String choice = scanner.next();

			switch (choice) {
			case "1":
				BoardSelect boardSelect = new BoardSelect();
				boardSelect.execute(scanner);
				System.out.println();

				break;
			case "2":
				BoardInsert boardInsert = new BoardInsert();
				boardInsert.execute(scanner);
				System.out.println();

				break;
			case "3":
				BoardUpdate boardUpdate = new BoardUpdate();
				boardUpdate.execute(scanner);
				System.out.println();

				break;

			case "4":
				BoardDelete boardDelete = new BoardDelete();
				boardDelete.execute(scanner);
				System.out.println();
				break;
			case "5":			
				MemberLoginMain.main(null);
				break;

			default:
				System.out.println("잘못 입력하셨습니다.");
				System.out.println();
				break;
			}

		} while (true);
	}

}
