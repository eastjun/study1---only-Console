package board.action;

import java.util.Scanner;

public interface BoardAction {

	public void execute(Scanner scanner);
}
