package board.control;


import java.util.ArrayList;
import java.util.Scanner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import board.DAO.BoardDAO;
import board.DTO.BoardDTO;
import board.action.BoardAction;

public class BoardUpdate implements BoardAction {


private static final Log log = LogFactory.getLog(BoardUpdate.class);

	@Override
	public void execute(Scanner scanner) {
		System.out.println("====글 수정 페이지 입니다====");
		BoardDAO boardDAO = new BoardDAO();
		
		System.out.println("===전체 글 목록 ===");
		
		ArrayList<BoardDTO> arrayList = new ArrayList<BoardDTO>();
		
		arrayList = boardDAO.boardSelectAll();
		for (BoardDTO boardDTO : arrayList) {
			int num = boardDTO.getNum();
			String title = boardDTO.getTitle();
			String content = boardDTO.getContent();
			String userid = boardDTO.getUserID();
			String writeday=boardDTO.getWriteday();
			System.out.print(" 글번호: "+ num);
			System.out.print(" 작성자: "+ userid);
			System.out.println(" 작성일:  "+ writeday);
			System.out.println(" 제목: "+ title);
			System.out.println(" 내용: "+ content);
			
			System.out.println();
		} 
		
		for (BoardDTO boardDTO : arrayList) {
			System.out.println("수정할 글 번호를 입력하세요.");
			System.out.println("글 번호: ");
			int num = scanner.nextInt();
			
			boardDTO =boardDAO.boardSelect(num);
			
			if (boardDTO.getNum()==0) {
				
				System.out.println("수정할 번호가 없습니다. 다시 입력하세요.");
				System.out.println();
				
			}
			else {
				System.out.println();
				log.info("번호 확인 - " + boardDTO.getNum());
				
				System.out.println();
				System.out.println("글 비밀번호를 입력해주세요.");
				System.out.println();
				System.out.print("비밀번호 : ");
				String password = scanner.next();
				if (boardDTO.getWpassword().equals(password)) {
					
					System.out.println("글을 수정하세요");
					System.out.println();
					System.out.println("현재 비밀번호: " +boardDTO.getWpassword() );
					System.out.print("수정할 비밀번호: ");
					String password2 = scanner.next();
					System.out.println("현재 제목: " +boardDTO.getTitle());
					System.out.print("수정할 제목: ");
					String title = scanner.next();
					System.out.println("현재 내용 : "+ boardDTO.getContent());
					System.out.print("수정할 내용: ");
					String content = scanner.next();
					
					boardDTO.setWpassword(password2);
					boardDTO.setTitle(title);
					boardDTO.setContent(content);
					
					boardDAO.boardUpdate(boardDTO);
					System.out.println("글 수정을 완료했습니다.");
					
					return;
					
				}
				else {
					System.out.println("비밀번호가 일치하지 않습니다.");
				}
				
			}	
		}
	}
}
