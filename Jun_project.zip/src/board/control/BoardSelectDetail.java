package board.control;

import java.util.Scanner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import board.DAO.BoardDAO;
import board.DTO.BoardDTO;
import board.action.BoardAction;

public class BoardSelectDetail implements BoardAction {

	private static final Log log = LogFactory.getLog(BoardSelectDetail.class);
	@Override
	public void execute(Scanner scanner) {
		BoardDAO boardDAO = new BoardDAO();
		System.out.println("검색할 글 번호를 입력하세요");
		System.out.println("글 번호: ");
		int num = scanner.nextInt();
		
		BoardDTO boardDTO = new BoardDTO();
		boardDTO = boardDAO.boardSelect(num);
		
		if (boardDTO.getNum()==0) {
			log.info("글 번호 -" +boardDTO.getNum());
			System.out.println("검색한 번호가 없습니다.");
			
		}
		else {
			num = boardDTO.getNum();
			
			String userID = boardDTO.getUserID();
			String title = boardDTO.getTitle();
			String content = boardDTO.getContent( );
			String writeday = boardDTO.getWriteday( );
			System.out.println("[내용] ");
			System.out.print("번호: " + num + "," + " ");
			System.out.print("작성자: " + userID + "," + " ");
			System.out.println("날짜: " + writeday);
			System.out.println("제목: " + title  + " ");		
			System.out.print("내용: " + content + " ");
			
			System.out.println( );
		}
		
	}

}
