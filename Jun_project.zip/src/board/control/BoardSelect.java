package board.control;

import java.util.ArrayList;
import java.util.Scanner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import board.DAO.BoardDAO;
import board.DTO.BoardDTO;
import board.action.BoardAction;

public class BoardSelect implements BoardAction {
	

	private static final Log log = LogFactory.getLog(BoardSelect.class);

	@Override
	public void execute(Scanner scanner) {
		
		System.out.println("==글 목록 페이지===");
		System.out.println("1. 전체 글 조회 2. 상세 글 조회 3. 아이디로 검색하기");
		System.out.print("번호 : ");
		String choice =scanner.next();
		
		BoardDAO boardDAO = new BoardDAO();
		
		ArrayList<BoardDTO> arrayList =new ArrayList<BoardDTO>();
		
		switch (choice) {
		case "1":
			
			arrayList=boardDAO.boardSelectAll();
			log.info("아이디 확인 -" +arrayList);
			
			for (BoardDTO boardDTO : arrayList) {
				int num = boardDTO.getNum();
				String title = boardDTO.getTitle();
				String content = boardDTO.getContent();
				String userid = boardDTO.getUserID();
				String writeday=boardDTO.getWriteday();
				System.out.print("글번호: "+ num+",");
				System.out.print("작성자: "+ userid+",");
				System.out.println(" 작성일:  "+ writeday);
				System.out.println("제목: "+ title);
				System.out.println("내용: "+ content);
				System.out.println();
			} 
			
			break;
			
		case "2":
			BoardSelectDetail boardSelectDetail = new BoardSelectDetail();
			boardSelectDetail.execute(scanner);
			System.out.println();
			
			break;
			
		case "3":
			System.out.println("검색할 아이디를 입력하세요.");
			System.out.print("아이디: ");
			String id = scanner.next();
			arrayList=boardDAO.boardIDCheck(id);
			
			for (BoardDTO boardDTO : arrayList) {
				int num = boardDTO.getNum();
				String title = boardDTO.getTitle();
				String content = boardDTO.getContent();
				String userid = boardDTO.getUserID();
				String writeday=boardDTO.getWriteday();
				System.out.println("글번호: "+ num);
				System.out.print("작성자: "+ userid+",");
				System.out.println(" 작성일:  "+ writeday);				
				System.out.println("제목: "+ title);
				System.out.println("내용: "+ content);
				
			} 
			
			break;

		default:
			System.out.println("잘못 입력하셨습니다.");
			BoardSelect boardSelect = new BoardSelect();
			boardSelect.execute(scanner);
			break;
		}
		
	}

}
