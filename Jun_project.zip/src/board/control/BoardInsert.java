package board.control;

import java.util.ArrayList;
import java.util.Scanner;

import board.DAO.BoardDAO;
import board.DTO.BoardDTO;
import board.action.BoardAction;
import member.DAO.MemberDAO;
import member.DTO.MemberDTO;

public class BoardInsert implements BoardAction{

	@Override
	public void execute(Scanner scanner) {
		System.out.println("====게시물 작성====");
		System.out.println("회원만 글을 작성할 수 있습니다.");
		MemberDAO memberDAO = new MemberDAO();
		ArrayList<MemberDTO> arrayList = new ArrayList<MemberDTO>();
		arrayList = memberDAO.memberSelectAll();
		
		for (MemberDTO memberDTO : arrayList) {
			System.out.print("아이디: ");
			String id =scanner.next();
			System.out.print("비밀번호: ");
			String password = scanner.next();
			
			memberDTO = memberDAO.memberLogin(id, password);
			System.out.println();
			
			if (memberDTO.getUserID()==null) {
				System.out.println("회원정보가 틀립니다.");	
				continue;
			}
			else {
				BoardDAO boardDAO = new BoardDAO();
				BoardDTO boardDTO = new BoardDTO();
				System.out.println("아이디 확인 완료!");
				System.out.print("글 비밀번호: ");
				String wpassword = scanner.next();
				//System.out.println("작성자: "+id);
				//String userID= scanner.next();
				System.out.print("제목: ");
				String title = scanner.next();
				System.out.print("내용: ");
				String content = scanner.next();
				
				boardDTO.setTitle(title);
				boardDTO.setContent(content);
				boardDTO.setUserID(id);
				boardDTO.setWpassword(wpassword);
				
				boardDAO.boardInsert(boardDTO);
			
				System.out.println("작성 완료");
				
				return;
			}
			
		}
		
	}

}
