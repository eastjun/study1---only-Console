package board.control;

import java.util.ArrayList;
import java.util.Scanner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import board.DAO.BoardDAO;
import board.DTO.BoardDTO;
import board.action.BoardAction;
import board.view.BoardMain;

public class BoardDelete implements BoardAction {

	private static final Log log = LogFactory.getLog(BoardDelete.class);

	@Override
	public void execute(Scanner scanner) {
		System.out.println();
		System.out.println("<<<글 삭제 페이지>>>");

		BoardDAO boardDAO = new BoardDAO();
		System.out.println("전체 글 목록");
		ArrayList<BoardDTO> arrayList = new ArrayList<BoardDTO>();

		arrayList = boardDAO.boardSelectAll();

		for (BoardDTO boardDTO : arrayList) {

			int num = boardDTO.getNum();
			String title = boardDTO.getTitle();
			String content = boardDTO.getContent();
			String userid = boardDTO.getUserID();
			String writeday = boardDTO.getWriteday();
			System.out.print(" 글번호: " + num);
			System.out.print(" 작성자: " + userid);
			System.out.println(" 작성일:  " + writeday);
			System.out.println(" 제목: " + title);
			System.out.println(" 내용: " + content);
			System.out.println();
		}
		for (BoardDTO boardDTO : arrayList) {
			System.out.println("삭제할 글 번호를 선택하세요.");
			System.out.print("번호 :");
			int num = scanner.nextInt();
			boardDTO = new BoardDTO();
			boardDTO = boardDAO.boardSelect(num);
			System.out.println();

			if (boardDTO.getNum() == 0) {

				System.out.println("삭제할 글이 없습니다. 다시 입력하세요.");
				log.info("번호 확인 -" + boardDTO.getNum());
				System.out.println();

			}

			else {
				System.out.println();
				System.out.println("글 비밀번호를 입력해주세요.");
				System.out.println();
				System.out.print("비밀번호 : ");
				String password = scanner.next();

				if (boardDTO.getWpassword().equals(password)) {
					System.out.println("비밀번호가 일치합니다.");
					System.out.println("정말로 글을 삭제하시겠습니까? (y/n)");
					String choice = scanner.next();
					switch (choice) {
					case "y":
						System.out.println("삭제 완료");
						boardDAO.boardDelete(num, password);
						BoardMain.main(null);

						break;
					case "n":
						System.out.println("삭제를 취소합니다.");
						BoardMain.main(null);

						break;

					default:
						System.out.println("잘못 입력하셨습니다.");
						break;
					}
				}
				else {
					System.out.println("비밀번호가 일치하지 않습니다.");
				}
			}
		}
	}
}
